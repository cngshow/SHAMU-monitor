@va_to_dod_sql = <<-eos
  select b.fault_detail as fault_detail, a.event_type as event_type, a.message_content as z03_xml, a.message_id as message_id
  from chdr2.audited_event a, chdr2.audited_event b
  where a.message_id = b.correlation_id
  and   A.CREATED_DATE BETWEEN TO_DATE ('START_DATE','yyyymmdd') AND TO_DATE ('END_DATE','yyyymmdd')
  and   A.sending_site = 'VHACHDR.MED.VA.GOV'
  and   a.receiving_site = 'DODCHDR.HA.OSD.GOV'
  and   a.event_type in ('FILL','PRES','ALGY')
  and   b.FAULT_DETAIL LIKE '%translation%'
  --and   rownum < 500
eos

@dod_to_va_sql = <<-eos
  select b.fault_detail as fault_detail, a.event_type as event_type, a.message_content as z03_xml, a.message_id as message_id
  from chdr2.audited_event a, chdr2.audited_event b
  where a.message_id = b.correlation_id
  and   A.CREATED_DATE BETWEEN TO_DATE ('START_DATE','yyyymmdd') AND TO_DATE ('END_DATE','yyyymmdd')
  and   a.sending_site = 'DODCHDR.HA.OSD.GOV'
  and   A.receiving_site = 'VHACHDR.MED.VA.GOV'
  and   a.event_type in ('FILL','PRES','ALGY')
  and   b.FAULT_CODE = '903'
  --and   rownum < 500
eos

@success_count_sql = <<-eos
	select case a.sending_site when 'DODCHDR.HA.OSD.GOV' then 'dod_to_va' else 'va_to_dod' end as direction,
				count(a.message_id) as z03_cnt
	from  chdr2.audited_event a, chdr2.audited_event b
	where a.message_id = b.correlation_id
  and   A.CREATED_DATE BETWEEN TO_DATE ('START_DATE','yyyymmdd') AND TO_DATE ('END_DATE','yyyymmdd')
	and   a.sending_site in ('DODCHDR.HA.OSD.GOV','VHACHDR.MED.VA.GOV')
	and   A.receiving_site in ('DODCHDR.HA.OSD.GOV','VHACHDR.MED.VA.GOV')
	and   a.event_type in ('FILL','PRES','ALGY')
	group by a.sending_site
eos

@site_name_sql = <<-eos
  select a.stationnumber as site_id, a.name as site_name
  from CHDR2.STD_INSTITUTION a, CHDR2.STD_FACILITYTYPE  b
  where a.FACILITYTYPE_ID = b.ID
  and   a.DEACTIVATIONDATE IS NULL
  and   b.ISMEDICALTREATING = 1
  and   length(a.stationnumber) = 3
  and   a.agency_id=1009121 -- VA agency
eos

def increment_count(direction, site_id, terminology_code, event_type, drug_name, z03_message_id)
	drug_code_event_type = terminology_code + "_" + (event_type.eql?("ALGY") ? "ALGY" : "PRES-FILL")
	@terminology_totals[direction][site_id] = {} if @terminology_totals[direction][site_id].nil?
	@terminology_totals[direction][site_id][drug_code_event_type] = {} if @terminology_totals[direction][site_id][drug_code_event_type].nil?
	@terminology_totals[direction][site_id][drug_code_event_type][:count] = 0 if @terminology_totals[direction][site_id][drug_code_event_type][:count].nil?
	@terminology_totals[direction][site_id][drug_code_event_type][:drug_name] = {} if @terminology_totals[direction][site_id][drug_code_event_type][:drug_name].nil?
	@terminology_totals[direction][site_id][drug_code_event_type][:drug_name][drug_name] = [] if @terminology_totals[direction][site_id][drug_code_event_type][:drug_name][drug_name].nil?
	@terminology_totals[direction][site_id][drug_code_event_type][:drug_name][drug_name] << z03_message_id
	@terminology_totals[direction][site_id][drug_code_event_type][:count] += 1
end

def write_html(data, site, direction)
	site_data = data[site].to_a.sort { |e, f| f[1][:count] <=> e[1][:count] }[0..(@top_failures-1)] unless data[site].nil?

	#another way to do this is below ... use reverse for descending order
	#site_data = data[site].sort_by { |k, v| v[:count]}.reverse.[0..(@top_failures-1)] unless data[site].nil?

	if (direction.eql?(:va_to_dod))
		site_name = @va_site_hash[site].nil? ? site : "#{site} - #{@va_site_hash[site]}"
	else
		site_name = "gotta get dod #{site} xref"
	end


	if (! site_data.nil?)
		ret = SITE_TABLE_START.clone
		ret.sub!("#DIRECTION#", direction.eql?(:va_to_dod) ? "VA to DoD" : "DoD to VA")
		ret.sub!("#SITE_H3#", "Terminology Failures for #{site.eql?(:all_sites) ? "All Sites" : site_name}")
		idx = 0

		site_data.each do |data|
			drug_code_type_array = data[0].split("_")
			drug_code = drug_code_type_array[0]
			event_type = drug_code_type_array[1]
			count = data[1][:count]
			drug_names = data[1][:drug_name].keys.join("<br>")

			#todo parameterize this!
			#break if count < 5 && idx > 0
			idx += 1
			row = DRUG_ROW.clone
			row.sub!("#GREENBAR#", idx%2 == 0 ? "even" : "odd")
			row.sub!("#EVENT_TYPE#", event_type.to_s)
			row.sub!("#DRUG_CODE#", drug_code.to_s)
			row.sub!("#DRUG_NAME#", drug_names.to_s)
			row.sub!("#COUNT#", count.to_s)
			ret += row
		end

		ret += SITE_TABLE_END.clone
	else
		ret = BAD_SITE.clone.sub("#SITE_H3#", site)
	end
	ret
end

SITE_TABLE_START = <<-eos
		<div class="site_border">
    <h1>Terminology Failures for #DIRECTION#</h1>
    <h3>#SITE_H3#</h3>
    <table class="sample" cellpadding="6" width="800px">
	<tr>
		<th width="10%">Event Type</th>
		<th width="30%">Drug Code</th>
		<th width="40%">Drug Name</th>
		<th width="20%">Count</th>
	</tr>
eos

DRUG_ROW = <<-eos
	<tr class="#GREENBAR#">
		<td align="left">#EVENT_TYPE#</td>
		<td align="left">#DRUG_CODE#</td>
		<td align="left">#DRUG_NAME#</td>
		<td align="left">#COUNT#</td>
	</tr>
eos

SITE_TABLE_END = <<-eos
    </table>
		</div>
    <br/><br/>
eos

BAD_SITE = <<-eos
    <h3>No data found for site code: #SITE_H3#</h3>
    <br/><br/>
eos

HEADER = <<-eos
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
	<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<title>Terminology Failure Report</title>
		<style type="text/css">
			html, body {
				color: navy;
				font-size: small;
			}
			div.rpt {
				text-align:  center;
				width: 800px;
				padding-left: 5px;
			}
			h2 {
				text-align: center;
			}
			h3 {
				text-align: left;
			}
			table.sample {
				border: solid;
				border-width: thin;
				border-color: navy;
				background-color: #eee;
			}
			table.sample th {
				text-align: bottom;
				background-color: navy;
				color: white;
			}
			.odd {
				background-color: #fff;
			}
			.even {
				background-color: "transparent";
			}
			div.site_border {
				border: solid;
				border-width: thin;
				border-color: #E8E8E8;
			}
		</style>
	</head>
	<body>
	<div class="rpt">
		<h2>Terminology Failure Report<br>For #START_DATE# thru #END_DATE#</h2>
		The following report breaks down Z03 Clinical Updates that failed terminology that were sent between the VA to DoD
		over the reporting period.
		<br/><br/>

eos

FOOTER = <<-eos
	</div>
	</body>
	</html>
eos

SUMMARY_TABLE_START = <<-eos
		<div class="site_border">
    <h1>Z03/Z04 Clinical Updates Summary Statistics</h1>
    <table class="sample" cellpadding="6" width="800px">
	<tr>
		<th width="20%">Z03 Sending Site</th>
		<th width="20%">Successful Z03s</th>
		<th width="20%">Failed Z03s</th>
		<th width="20%">Total Messages Sent</th>
		<th width="20%">Success Percentage</th>
	</tr>
eos

SUMMARY_ROW = <<-eos
	<tr class="#GREENBAR#">
		<td align="left">#SENDING_SITE#</td>
		<td align="right">#SUCCESS_COUNT#</td>
		<td align="right">#FAILURE_COUNT#</td>
		<td align="right">#TOTAL_COUNT#</td>
		<td align="right">#SUCCESS_PCT#%</td>
	</tr>
eos

SUMMARY_TABLE_END = <<-eos
    </table>
		</div>
    <br/><br/>
eos