# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
PSTDashboard::Application.config.secret_token = '3c5d6f5d12060b0f21274c2f51e56bd7f067cd9f6631c83a318a8125d90e261f8efd850b1b78d43b816adfcc5b241a93d78a625f42ebaba8b02183a1c2984d73'
